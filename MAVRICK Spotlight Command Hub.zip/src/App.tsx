import { useState, type ReactNode } from "react";

type IconName =
  | "bolt"
  | "check"
  | "chevron"
  | "clipboard"
  | "close"
  | "download"
  | "folder"
  | "grid"
  | "memory"
  | "search"
  | "spark"
  | "terminal"
  | "trash"
  | "undo";

const iconPaths: Record<IconName, ReactNode> = {
  bolt: <path d="M12.8 1.7 4.9 11h6l-1.7 7.3 7.9-9.3h-6l1.7-7.3Z" />,
  check: <path d="m4 10.5 3.2 3.2L16 5" />,
  chevron: <path d="m7.5 5 5 5-5 5" />,
  clipboard: (
    <>
      <rect x="5" y="4" width="11" height="14" rx="2" />
      <path d="M8 4.5V3.2C8 2.5 8.5 2 9.2 2h2.6c.7 0 1.2.5 1.2 1.2v1.3M2.5 14V7c0-1.1.9-2 2-2" />
    </>
  ),
  close: <path d="m5 5 10 10M15 5 5 15" />,
  download: <path d="M10 2v11m0 0 4-4m-4 4L6 9M3 17h14" />,
  folder: (
    <path d="M2.5 6.5h15v9a2 2 0 0 1-2 2h-11a2 2 0 0 1-2-2v-9Zm0 0V5a2 2 0 0 1 2-2h3l2 2h6a2 2 0 0 1 2 2" />
  ),
  grid: (
    <>
      <rect x="2.5" y="3" width="15" height="14" rx="2" />
      <path d="M10 3v14" />
    </>
  ),
  memory: (
    <>
      <rect x="4" y="4" width="12" height="12" rx="2" />
      <path d="M7 1.5V4m3-2.5V4m3-2.5V4M7 16v2.5m3-2.5v2.5m3-2.5v2.5M1.5 7H4m-2.5 3H4m-2.5 3H4M16 7h2.5M16 10h2.5M16 13h2.5M8 8h4v4H8z" />
    </>
  ),
  search: (
    <>
      <circle cx="8.5" cy="8.5" r="5.5" />
      <path d="m12.5 12.5 4 4" />
    </>
  ),
  spark: <path d="M10 2.2 12 8l5.8 2-5.8 2-2 5.8L8 12l-5.8-2L8 8l2-5.8Z" />,
  terminal: <path d="m3 5 4 4-4 4m6 1h7" />,
  trash: <path d="M3 5h14M8 2h4l1 3M5 5l1 12h8l1-12M8 8v6m4-6v6" />,
  undo: <path d="M5 7H1.8L5 3.8M2.4 7A7 7 0 1 1 4 14" />,
};

function Icon({ name, size = 16 }: { name: IconName; size?: number }) {
  return (
    <svg
      aria-hidden="true"
      width={size}
      height={size}
      viewBox="0 0 20 20"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {iconPaths[name]}
    </svg>
  );
}

function Shortcut({ children }: { children: ReactNode }) {
  return <kbd className="keycap">{children}</kbd>;
}

function Header({
  status = "Warm AI Core",
  active = false,
}: {
  status?: string;
  active?: boolean;
}) {
  return (
    <div className="hub-header">
      <div className="brand-group">
        <span className="brand">
          <span className="brand-mark">M</span>
          MAVRICK
        </span>
        <span className={`status-pill ${active ? "active" : ""}`}>
          <span className="status-dot" />
          {status}
        </span>
      </div>
      <div className="header-actions">
        <Shortcut>Super + M</Shortcut>
        <button className="icon-button" aria-label="Close">
          <Icon name="close" size={14} />
        </button>
      </div>
    </div>
  );
}

function SearchBox({
  value,
  placeholder,
  active = false,
}: {
  value?: string;
  placeholder?: string;
  active?: boolean;
}) {
  return (
    <div className={`search-box ${active ? "focused" : ""}`}>
      <span className="spark-icon">
        <Icon name="spark" size={16} />
      </span>
      <span className={value ? "query-value" : "placeholder"}>{value ?? placeholder}</span>
      {value && <span className="cursor" />}
      <span className="search-mode">ASK</span>
    </div>
  );
}

const actions: Array<{ icon: IconName; label: string }> = [
  { icon: "grid", label: "Split Screen" },
  { icon: "memory", label: "Memory Telemetry" },
  { icon: "bolt", label: "System Health" },
  { icon: "folder", label: "Clean Downloads" },
  { icon: "download", label: "Install App" },
];

function QuickActions() {
  return (
    <div className="quick-actions">
      {actions.map((action) => (
        <button className="action-chip" key={action.label}>
          <Icon name={action.icon} size={12} />
          {action.label}
        </button>
      ))}
    </div>
  );
}

function Footer() {
  return (
    <div className="hub-footer">
      <div className="hints">
        <span>
          <Shortcut>Enter</Shortcut> Run
        </span>
        <span>
          <Shortcut>Esc</Shortcut> Dismiss
        </span>
        <span>
          <Shortcut>Tab</Shortcut> Suggest
        </span>
      </div>
      <span className="model">
        <span className="model-dot" />
        Antigravity Gemini 3.8 Flash
      </span>
    </div>
  );
}

function FrameLabel({
  index,
  title,
  dimensions,
}: {
  index: string;
  title: string;
  dimensions: string;
}) {
  return (
    <div className="frame-label">
      <div>
        <span className="frame-index">{index}</span>
        <span>{title}</span>
      </div>
      <span>{dimensions}</span>
    </div>
  );
}

function Frame({
  children,
  height,
  className = "",
}: {
  children: ReactNode;
  height: number;
  className?: string;
}) {
  return (
    <section className={`hub-frame ${className}`} style={{ height }}>
      {children}
    </section>
  );
}

const processes = [
  { name: "brave", detail: "24 processes", ram: "2,842", percent: "17.4", top: true },
  { name: "code", detail: "11 processes", ram: "1,936", percent: "11.8" },
  { name: "gnome-shell", detail: "system", ram: "824", percent: "5.0" },
  { name: "figma-linux", detail: "6 processes", ram: "612", percent: "3.7" },
  { name: "pipewire", detail: "system", ram: "188", percent: "1.1" },
];

function ActionButton({
  children,
  icon,
  danger = false,
  onClick,
}: {
  children: ReactNode;
  icon?: IconName;
  danger?: boolean;
  onClick?: () => void;
}) {
  return (
    <button className={`mini-button ${danger ? "danger" : ""}`} onClick={onClick}>
      {icon && <Icon name={icon} size={12} />}
      {children}
    </button>
  );
}

function IdleFrame() {
  return (
    <div className="frame-wrap">
      <FrameLabel index="01" title="IDLE / SPOTLIGHT CAPSULE" dimensions="740 × 140" />
      <Frame height={140} className="idle-frame">
        <Header />
        <SearchBox placeholder="Ask Mavrick anything... (e.g. ‘what is ram eating’, ‘split screen brave’, ‘install vscode’)" />
        <QuickActions />
        <Footer />
      </Frame>
    </div>
  );
}

function ReasoningFrame() {
  return (
    <div className="frame-wrap">
      <FrameLabel index="02" title="ACTIVE REASONING / STREAMING" dimensions="740 × 260" />
      <Frame height={260} className="expanded-frame">
        <Header status="Inspecting System Telemetry..." active />
        <SearchBox value="what is ram eating" active />
        <div className="reasoning-pane">
          <div className="reasoning-kicker">
            <span className="reasoning-glyph">
              <Icon name="terminal" size={13} />
            </span>
            <span>LIVE REASONING</span>
            <span className="stream-dots">
              <i />
              <i />
              <i />
            </span>
          </div>
          <p>Inspecting active processes sorted by memory consumption.</p>
          <div className="shimmer-track">
            <span />
          </div>
          <div className="reasoning-meta">
            <span>Reading /proc/meminfo</span>
            <span>164 processes indexed</span>
          </div>
        </div>
        <Footer />
      </Frame>
    </div>
  );
}

function ResultFrame() {
  const [copied, setCopied] = useState(false);
  const [killed, setKilled] = useState(false);

  const copyOutput = () => {
    const output = processes
      .map((process) => `${process.name}\t${process.ram} MB\t${process.percent}%`)
      .join("\n");
    void navigator.clipboard?.writeText(output);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1400);
  };

  return (
    <div className="frame-wrap">
      <FrameLabel index="03" title="RESULT INSPECTION / TELEMETRY" dimensions="740 × 380" />
      <Frame height={380} className="result-frame">
        <Header />
        <SearchBox value="what is ram eating" />
        <div className="result-toolbar">
          <div className="result-heading">
            <span className="result-icon">
              <Icon name="memory" size={15} />
            </span>
            <div>
              <strong>Memory consumers</strong>
              <span>Live snapshot · 16.0 GB total</span>
            </div>
          </div>
          <div className="result-actions">
            <ActionButton icon={copied ? "check" : "clipboard"} onClick={copyOutput}>
              {copied ? "Copied" : "Copy Output"}
            </ActionButton>
            <ActionButton icon="trash" danger onClick={() => setKilled(true)}>
              {killed ? "Stopped" : "Kill Process"}
            </ActionButton>
            <ActionButton>
              Dismiss <Shortcut>Esc</Shortcut>
            </ActionButton>
          </div>
        </div>
        <div className="process-table" role="table" aria-label="Process memory usage">
          <div className="table-row table-head" role="row">
            <span>PROCESS</span>
            <span>RAM (MB)</span>
            <span>% MEM</span>
          </div>
          {processes.map((process, index) => (
            <div
              className={`table-row ${process.top ? "top-process" : ""} ${killed && index === 0 ? "killed" : ""}`}
              role="row"
              key={process.name}
            >
              <span className="process-name">
                {process.top && <i />}
                <strong>{process.name}</strong>
                <small>{killed && index === 0 ? "process stopped" : process.detail}</small>
              </span>
              <span>{killed && index === 0 ? "—" : process.ram}</span>
              <span>{killed && index === 0 ? "—" : process.percent}</span>
            </div>
          ))}
        </div>
        <div className="table-footer">
          <span>Showing top 5 of 164</span>
          <span>Updated just now</span>
        </div>
      </Frame>
    </div>
  );
}

function WindowPreview() {
  return (
    <div className="window-preview">
      <div className="display-bar">
        <span className="display-dots">
          <i />
          <i />
          <i />
        </span>
        <span>WORKSPACE 1 · 1920 × 1080</span>
        <span>50 / 50</span>
      </div>
      <div className="window-panes">
        <div className="window-pane youtube-pane">
          <div className="pane-title">
            <span className="site-mark youtube-mark" />
            <span>YouTube</span>
            <small>960 px</small>
          </div>
          <div className="browser-chrome">
            <i />
            <span />
          </div>
          <div className="video-card">
            <span className="play-button" />
            <small>12:42</small>
          </div>
        </div>
        <div className="window-pane editor-pane">
          <div className="pane-title">
            <span className="site-mark leetcode-mark">L</span>
            <span>LeetCode</span>
            <small>960 px</small>
          </div>
          <div className="editor-body">
            <div className="problem-lines">
              <i />
              <i />
              <i />
            </div>
            <div className="code-lines">
              <i />
              <i />
              <i />
              <i />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function SplitFrame() {
  const [arranged, setArranged] = useState(true);

  return (
    <div className="frame-wrap">
      <FrameLabel index="04" title="SPLIT-SCREEN / EXECUTION" dimensions="740 × 320" />
      <Frame height={320} className="split-frame">
        <Header status={arranged ? "Execution complete" : "Action reverted"} />
        <SearchBox value="put youtube and leetcode side by side in brave" />
        <WindowPreview />
        <div className={`confirmation ${arranged ? "" : "undone"}`}>
          <span className="confirmation-icon">
            <Icon name={arranged ? "check" : "undo"} size={12} />
          </span>
          <strong>
            {arranged ? "Arranged 2 windows on current workspace" : "Window arrangement restored"}
          </strong>
          <span className="confirmation-detail">Brave · Workspace 1</span>
          <button onClick={() => setArranged((value) => !value)}>
            <Icon name="undo" size={12} />
            {arranged ? "Undo" : "Arrange again"}
          </button>
        </div>
      </Frame>
    </div>
  );
}

export default function App() {
  return (
    <main className="app-shell">
      <header className="page-header">
        <div className="page-brand">
          <span className="page-monogram">M</span>
          <div>
            <strong>MAVRICK</strong>
            <span>Command intelligence for Linux</span>
          </div>
        </div>
        <div className="page-meta">
          <span className="online">
            <i />
            System ready
          </span>
          <span>Super + M</span>
        </div>
      </header>
      <div className="showcase">
        <IdleFrame />
        <ReasoningFrame />
        <ResultFrame />
        <SplitFrame />
      </div>
    </main>
  );
}
